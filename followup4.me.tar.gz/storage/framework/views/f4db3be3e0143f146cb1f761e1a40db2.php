
    <?php if(session('success')): ?>
    <div class="p-4 sm:p-8 text-green-900 bg-green-400 border-1 border-solid border-green-900 shadow-inner shadow sm:rounded-lg">
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(session('failure')): ?>
        <div class="p-4 sm:p-8 text-red-900 bg-red-400 border-1 border-solid border-red-900 shadow-inner shadow sm:rounded-lg">
            <div class="alert alert-danger">
                <?php echo e(session('failure')); ?>

            </div>
        </div>
    <?php endif; ?>
<?php /**PATH /var/www/ourapp/resources/views/includes/alert.blade.php ENDPATH**/ ?>