<div>
    <p>Hi <strong><?php echo e($payload['from']); ?></strong></p>

    <p>Here are the details:<br>
    <strong>Subject:</strong> <?php echo e($payload['subject']); ?><br>
    <strong>To:</strong> <?php echo e($payload['to']); ?><br>
    </p>

    <p>You have requested a reminder in <strong><?php echo e($payload['duration']); ?> days</strong>. See you then! (<strong><?php echo e($payload['date']); ?></strong>)</p>
    
    <p>Regards,<br>
    The followup4.me team<br>
    </p>
    <br>
    <hr>
    <br>
    <a href="https://remindr.cc/email-reminder/snooze/<?php echo e($payload['emailID']); ?>">Snooze This Reminder</a><br>
    <a href="https://remindr.cc/email-reminder/reminder-confirmations/<?php echo e($payload['emailID']); ?>">Disable reminder confirmations</a><br>
    <a href="https://remindr.cc/dashboard">My Dashboard</a><br>
    <a href="https://remindr.cc/email-reminder/<?php echo e($payload['emailID']); ?>">View Reminder</a><br>
    <a href="https://remindr.cc/email-reminder/edit/<?php echo e($payload['emailID']); ?>">Edit Reminder</a><br>
</div><?php /**PATH /var/www/ourapp/resources/views/test_email.blade.php ENDPATH**/ ?>