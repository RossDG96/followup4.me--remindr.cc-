<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <?php if(session('success')): ?>
                    <div class="p-6 text-green-900 bg-green-400 border-1 border-solid border-green-900 shadow-inner">
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <?php if(session('failure')): ?>
                    <div class="p-6 text-red-900 bg-red-400 border-1 border-solid border-red-900 shadow-inner">
                        <div class="alert alert-danger">
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="my-5 bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php if($count < 1): ?>
                    <div class="text-gray-900 dark:text-gray-100">
                        BCC <strong>1@remindr.cc</strong> to start seeing reminders here
                    </div>
                    <?php else: ?>
                        <h2 class="text-2xl font-black">Your Email Reminders</h2>
                        <p class="mb-5 text-gray-500">For: <?php echo e($email); ?></p>
                        <div class="grid">
                            <div class="grid font-black" style="grid-template-columns: 1fr 1fr 1fr 150px 150px 50px 50px 50px;">
                                <div class="flex content-center">Subject</div>
                                <div class="flex content-center">From</div>
                                <div class="flex content-center">Recipient</div>
                                <div class="flex content-center">Sent Date</div>
                                <div class="flex content-center">Reminder Date</div>
                                <div class="flex justify-center content-center"><?php echo $__env->make('svg.duration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                <div class="flex justify-center content-center"><?php echo $__env->make('svg.send', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                <div class="flex justify-center content-center"><?php echo $__env->make('svg.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                            </div>
                            
                            <?php $__currentLoopData = $emailReminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid text-gray-400 divide-y divide-gray-400" style="grid-template-columns: 1fr 1fr 1fr 150px 150px 50px 50px 50px;">
                                <div class="py-3">
                                    <a href="/email-reminder/<?php echo e($reminder->id); ?>"><?php echo e($reminder->subject); ?></a>
                                </div>
                                <div class="py-3">
                                    <a href="/email-reminder/<?php echo e($reminder->id); ?>"><?php echo e($reminder->sender); ?></a>
                                </div>
                                <div class="py-3">
                                    <a href="mailto:<?php echo e($reminder->recipient); ?>">
                                        <?php echo e($reminder->recipient); ?>

                                    </a>
                                </div>
                                <div class="py-3"><?php echo e($reminder->email_date); ?></div>
                                <div class="py-3"><?php echo e($reminder->reminder_date); ?></div>
                                <div class="flex justify-center content-center py-3"><?php echo e($reminder->reminder_period); ?></div>
                                <?php if($reminder->sent == 1): ?>
                                    <div class="flex justify-center content-center py-3 text-green-400"><?php echo $__env->make('svg.check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                <?php else: ?>
                                    <div class="flex justify-center content-center py-3 text-red-400"><?php echo $__env->make('svg.cross', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                <?php endif; ?>
                                <div class="flex justify-center content-center py-3">
                                    <a href="/email-reminder/archive/<?php echo e($reminder->id); ?>"><?php echo $__env->make('svg.archive', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                                    &nbsp;&nbsp;
                                    <a href="/email-reminder/snooze/<?php echo e($reminder->id); ?>"><?php echo $__env->make('svg.snooze', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($arhivedEmailsCount > 0): ?>
                        <h2 class="text-2xl font-black mt-10">Your Archived Emails</h2>
                        <p class="mb-5 text-gray-500">For: <?php echo e($email); ?></p>
                        <div class="grid">
                            <div class="grid font-black" style="grid-template-columns: 1fr 1fr 1fr 150px 150px 50px 50px 50px;">
                                <div class="flex content-center">Subject</div>
                                <div class="flex content-center">From</div>
                                <div class="flex content-center">Recipient</div>
                                <div class="flex content-center">Sent Date</div>
                                <div class="flex content-center">Reminder Date</div>
                                <div class="flex justify-center content-center"><?php echo $__env->make('svg.duration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                <div class="flex justify-center content-center"><?php echo $__env->make('svg.send', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                <div class="flex justify-center content-center"><?php echo $__env->make('svg.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                            </div>
                            
                            <?php $__currentLoopData = $archivedEmails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid text-gray-400 divide-y divide-gray-400" style="grid-template-columns: 1fr 1fr 1fr 150px 150px 50px 50px 50px;">
                                <div class="py-3"><?php echo e($reminder->subject); ?></div>
                                <div class="py-3">
                                    <a href="/email-reminder/<?php echo e($reminder->id); ?>"><?php echo e($reminder->sender); ?></a>
                                </div>
                                <div class="py-3">
                                    <a href="mailto:<?php echo e($reminder->recipient); ?>">
                                        <?php echo e($reminder->recipient); ?>

                                    </a>
                                </div>
                                <div class="py-3"><?php echo e($reminder->email_date); ?></div>
                                <div class="py-3"><?php echo e($reminder->reminder_date); ?></div>
                                <div class="flex justify-center content-center py-3"><?php echo e($reminder->reminder_period); ?></div>
                                    <?php if($reminder->sent == 1): ?>
                                        <div class="flex justify-center content-center py-3 text-green-400"><?php echo $__env->make('svg.check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                    <?php else: ?>
                                        <div class="flex justify-center content-center py-3 text-red-400"><?php echo $__env->make('svg.cross', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                                    <?php endif; ?>
                                <div class="flex justify-center content-center py-3">
                                        <a href="/email-reminder/unarchive/<?php echo e($reminder->id); ?>"><?php echo $__env->make('svg.archive', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                                        &nbsp; &nbsp;
                                        <a class="text-red-500" href="/email-reminder/delete/<?php echo e($reminder->id); ?>"><?php echo $__env->make('svg.trash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/ourapp/resources/views/dashboard.blade.php ENDPATH**/ ?>