<div class="text-white font-black">
 remindr.cc
</div>
<?php /**PATH /var/www/ourapp/resources/views/components/application-logo.blade.php ENDPATH**/ ?>