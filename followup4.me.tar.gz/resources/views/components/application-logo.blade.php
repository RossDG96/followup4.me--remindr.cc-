<div class="text-white font-black">
 remindr.cc
</div>
