<div>
    <p>Hi <strong><?php echo e($payload['from']); ?></strong>, reminder about the following:</p>
    
    <p>
    <strong>Subject:</strong> <?php echo e($payload['subject']); ?><br>
    <strong>To:</strong> <?php echo e($payload['to']); ?><br>
    </p>

    <p>Regards,<br>
    The followup4.me team<br>
    </p>
    <br>
    <hr>
    <br>
    <a href="https://remindr.cc/dashboard">My Dashboard</a><br>
    <a href="https://remindr.cc/email-reminder/<?php echo e($payload['emailID']); ?>">View Reminder</a><br>
</div><?php /**PATH /var/www/ourapp/resources/views/mails/daily-reminder-email.blade.php ENDPATH**/ ?>